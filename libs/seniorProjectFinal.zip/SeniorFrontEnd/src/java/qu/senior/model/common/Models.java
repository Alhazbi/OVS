package qu.senior.model.common;

public interface Models {
    String nmap(String ip);
}
