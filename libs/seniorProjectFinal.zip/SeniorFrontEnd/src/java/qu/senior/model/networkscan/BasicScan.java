/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qu.senior.model.networkscan;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.ejb.Stateless;
import qu.senior.entities.NmapHost;
@Stateless
public class BasicScan {

    public List<NmapHost> getNmapHost(String ip) {

       // String ip = "10.20.150.*";
        //String ip = "10.20.150.0/24"; // intire supnet
        //String ip = "10.20.150.*"; // range
        //String ip = "10.20.150.76-200"; // range
        //String ip = "10.20.150.1,2,3,4"; // multi ips
        List<NmapHost> hosts = new ArrayList<NmapHost>();
        
        Nmap n = new Nmap();
        String fullReport = n.nmapScan(ip);
      //  System.out.println(fullReport);
       String hostIp;
       String report;
        
    String paraRegex="Nmap scan report for.*\nHost is up(.|\n)*?Network Distance: \\d hops?";
    String ipRegex = "\\b\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\b";
    String ipRegexDown = "\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\[host down\\]";
    Pattern paraPatt = Pattern.compile(paraRegex);    
    Pattern ipPatt = Pattern.compile(ipRegex);
    Pattern ipPattDown = Pattern.compile(ipRegexDown);
    Matcher ipMatcher;
    Matcher ipDownMatcher; 
    Matcher paraMat = paraPatt.matcher(fullReport); 
    
    
    //find report for opened hosts
    while(paraMat.find()){
        report=paraMat.group();
    	System.out.println("Report:------------------------------\n"+report);

    	
        
         ipMatcher= ipPatt.matcher(report);
         if(ipMatcher.find()){
         hostIp = ipMatcher.group();
         report=report.replaceAll("\n", "</br>");
         hosts.add(new NmapHost(hostIp,true,report));
         }
    	}
    
    ipDownMatcher = ipPattDown.matcher(fullReport);
    
        while(ipDownMatcher.find()){
        ipMatcher= ipPatt.matcher(ipDownMatcher.group());
        if(ipMatcher.find())
         hosts.add(new NmapHost(ipMatcher.group(), false, ""));
        }
        return hosts;
    }
}
