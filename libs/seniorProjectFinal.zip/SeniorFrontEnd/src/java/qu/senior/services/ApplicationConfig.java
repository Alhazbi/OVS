package qu.senior.services;

import javax.ws.rs.core.Application;

@javax.ws.rs.ApplicationPath("rs")
public class ApplicationConfig extends Application {
}
